def sigmoid_derivative(a):
    # assumes sigmoided input
    
    derivative = a * (1-a)
    
    return derivative
