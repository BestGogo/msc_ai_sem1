package levelGenerators.GroupAA;

import engine.core.MarioLevelModel;
import engine.helper.MarioTimer;
import levelGenerators.MarioLevelGenerator;

import java.io.*;
import java.util.*;

import static java.lang.Math.abs;
import static java.lang.Math.min;
import static jdk.nashorn.internal.objects.NativeMath.max;


public class LevelGenerator implements MarioLevelGenerator {

    // Class for defining positions
    public class Vector2d {

        public int x;
        public int y;

        Vector2d(int x, int y){
            this.x = x;
            this.y = y;
        }

        Vector2d(){
            x=0;
            y=0;
        }
    }

    private final int rows = 16;    // map height
    private final int columns = 150;    // map width
    private int NTD =  2; // number of files to be read for training
    private int type = 1; //map type (notch, linear or benWeber)
    private Random random = new Random(); // for the touch of randomness in generation
    private int d_type = 1; // type of dependency
    private int splits = 4; // specify the number of horizontal splits
    private int difficulty = 2; // sets the difficulty for the Mario level
    private int corrections = 0; // keeps count of the number of times filter corrected the level
    private int random_counts = 0; // keeps count of the number of times an element had to be generated randomly
    // Constructors for the class

    public LevelGenerator(int type, int NTD) {
        this.NTD = NTD;
        this.type = type;
    }

    public LevelGenerator(int type, int NTD, int splits, int d_type, int difficulty){
        this.NTD = NTD;
        this.type = type;
        this.splits = splits;
        this.d_type = d_type;
        this.difficulty = difficulty;
    }

    public LevelGenerator(){
        this.NTD = 2;
        this.type = 1;
    }


    /***
     *
     * This function reads from the given txt files of mario levels and returns these levels as a 3D array of characters.
     *
     * @param type :- informs about the type of map (for eg. notch, original etc.) being considered for training data
     * @param kitna :- tells how many levels to be considered
     *
     * @return :- A 3D array of characters that stores tiles at x,y coordinates of a level for n levels.
     */

    public char[][][] generateTrainData(int type, int kitna){

        String path = new String();
        String read_data = new String();
        char[][][] traindata = new char[rows][columns][kitna];
        int r = 0;
        int c = 0;
        int num = 0;

        // Loop to read the files
        for (int n=1; n<=kitna;n++) {

            // Setting the path for reading a file
            // type 1 = original

            if (type == 1) {
                if(kitna > 15) {
                    kitna = 15;
                }
                if(n == 15){
                    System.out.println("Max 15 maps in Train Data");
                }
                path = "levels\\original\\lvl-";
            }

            // type 2 = linear

            if (type == 2) {
                if(kitna > 100) {
                    kitna = 100;
                }
                if(n == 100) {
                    System.out.println("Max 100 maps in Train Data");
                }
                    path = "src\\levelGenerators\\GroupAA\\TrainLevels\\Linear\\level";
            }

            // type 3 = notch

            if (type == 3) {
                if(kitna > 100) {
                    kitna = 100;
                }
                if(n == 100) {
                    System.out.println("Max 100 maps in Train Data");
                }
                path = "src\\levelGenerators\\GroupAA\\TrainLevels\\notch\\level";
            }
            // Setting the path of files in the variable 'path'
            path = path + n + ".txt";

            FileInputStream padh_re = null;

            try {
                padh_re = new FileInputStream(path);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            Scanner gmd = new Scanner(padh_re);
            r=0;

            // Read from the file in the current path
            while (gmd.hasNext()) {
                if (r >= rows) {
                    r = 0;
                    num++;
                }
                read_data = gmd.next();
                for (int pad = read_data.length(); pad<150; pad++) {

                    read_data = read_data + " ";

                }

                // Add the read file in the array 3D 'traindata'

                for (int y = 0; y < 150; y++) {
                    traindata[r][c][num] = read_data.charAt(y);
                    c++;
                }

                c = 0;
                r++;
            }
            gmd.close();
            try {
                padh_re.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            num++;
        }
        return traindata;
    }

    /***

     This function provides the markov chain function with the positions/states to be considered dependencies of a current position/state
     The relation of dependency states and d_type is provided in the report !!!

     Params :-
     x :- x-coordinate of the current state
     y :- y-coordinate of the current state

     Returns:- list of dependent state's x,y coordinates

     */
    public ArrayList<Vector2d> dependencies(int x, int y){

        // list of positions will be stored in the list 'positions' based on the type of dependency
        ArrayList<Vector2d> positions = new ArrayList<>();
        Vector2d pos = new Vector2d(x,y);

        // adding x,y values in the list 'positions' based on the type of dependency (i.e. d_type)
        if(d_type==1){
            pos.x = x;
            pos.y = y - 1;
            positions.add(pos);
        }

        if(d_type==2){
            pos.x = x - 1;
            pos.y = y;
            positions.add(pos);
            pos.x = x;
            pos.y = y - 1;
            positions.add(pos);
        }

        if(d_type==3){
            pos.x = x;
            pos.y = y - 1;
            positions.add(pos);
            pos.x = x;
            pos.y = y - 2;
            positions.add(pos);
        }

        if(d_type == 4){
            pos.x = x - 1;
            pos.y = y - 1;
            positions.add(pos);
            pos.x = x;
            pos.y = y - 1;
            positions.add(pos);
        }

        if(d_type==5) {
            pos.x = x - 1;
            pos.y = y;
            positions.add(pos);
            pos.x = x - 1;
            pos.y = y - 1;
            positions.add(pos);
            pos.x = x;
            pos.y = y - 1;
            positions.add(pos);
        }

        if(d_type == 6){
            pos.x = x - 1;
            pos.y = y;
            positions.add(pos);
            pos.x = x;
            pos.y = y - 1;
            positions.add(pos);pos.x = x;
            pos.y = y - 2;
            positions.add(pos);
        }

        return positions;
    }

    /***

     Calculates the Probability distribution (one of our generation techniques) of the tiles for each positions through the given train data
     Params:
     data :- a 3D array containing the levels in train data
     section :- if using splits ..... which split number we calculate the distribution
     domain :- For what domain of Tiles (i.e enemytiles, blocktiles etc) are we calculating the Probability

     Returns Probability Array

     */
    public double[][][] Probability_Distribution(char[][][] data, int section, char[] domain){

        // variable 'len' stores the number of available tiles.

        int len = domain.length;

        // Prob_dist is a 3D array that stores the probability distribution of each tile at x,y positions throughout the train data

        double[][][] Prob_dist= new double[rows/splits][columns][len];

        // Logic to encapsulate probability distribution in 'Prob_dist'

        // for handling the row values in case of different horizontal splits
        int model_row = (rows * (section-1))/splits;

        // Loop to count the number of tiles at x,y throughout the map
        for(int x = 0; x < (rows/splits); x++){
            for(int y=0; y < columns; y++){
                for(int n=0; n < NTD; n++) {
                    for (int t = 0; t < len; t++) {
                        if (data[model_row][y][n] == domain[t]) {

                            Prob_dist[x][y][t]++;

                        }
                    }
                }
            }
            model_row++;
        }

        //Calculation of Probabilities

        for(int x = 0; x < (rows/splits); x++) {
            for (int y = 0; y < columns; y++) {
                for (int t = 0; t < len; t++) {

                    Prob_dist[x][y][t] = Prob_dist[x][y][t]/NTD;
                }
            }
        }

        return Prob_dist;
    }

    /***

     Markov Chain functions that takes the dependencies and then returns the probabilities of all the tiles in
     throughout the train data for those dependent states ...
     Params :
     x :- x coordinate of the current state
     y :- y coordinate of the current state
     data :- the train data levels
     domain :- the domain of tiles being considered

     Returns :- Probability array

     */
    public double[] MarkovChain(int x, int y, char[][][] data, char[] domain){

        // Container for the positions ...
        ArrayList<Vector2d> pos = dependencies(x,y);
        int n_dependence = pos.size();

        // Container for the probability values
        double[] P = new double[domain.length];

        // Loop for calculation of the probabilities of tiles at the dependent states
        for(int t=0; t<domain.length; t++){

            for (int dt=0; dt < n_dependence; dt++) {

                for (int n = 0; n < NTD; n++) {

                    if(data[pos.get(dt).x][pos.get(dt).y][n] == domain[t]){

                        P[t]++;

                    }
                }
            }

            P[t] = P[t]/(NTD*(pos.size()));
        }

        return P;

    }

    /***

     Function Build Scene sets the tiles from the given domain at positions x,y taking into consideration all the
     techniques implemented (i.e Probability Distribution, Markov Chain, splits, dependencies etc)

     Params :-
     model :- an object of class MarioLevelModel used here for getting and setting tiles at specific x,y coordinates in a level
     data :- contains the train data
     s :- represents the section or split that we are supposed to be working on
     domain :- the domain or the tiles being considered for building (Blocking or Non Blocking)

     */

    public void BuildScene(MarioLevelModel model, char[][][] data, int s, char[] domain, String str){

        char[] tiles = domain;

        // count contains the probability distribution of the tiles at the current split
        double[][][] count = Probability_Distribution(data, s, tiles);

        // thresh is the threshold value below which markov won't be selected and level generation would be done by
        // probability distribution
        double thresh = 0;

        // different domains have different probability distributions hence different thresholds ...
        if(str == "NonBlock"){
            thresh = 0.1;
        }
        if(str == "Block"){
            thresh = 0.06;
        }
        if(str == "Collect"){
            thresh = (0.0001 + (difficulty/1000));
        }

        // model_row stores the actual row number irrespective of the split. We don't want to build the scenes for same
        // split every time.
        int model_row = (rows * (s - 1))/splits;

        // The 2D array scene contains the tiles distribution for the current split.
        char[][] scene = new char[rows/splits][columns];

        // pe will take the markov chain's returned probability estimation values
        double[] pe = new double[domain.length];

        int maxID = 0;
        double max=0;

        // traversing the current split in top-down left-right way
            for (int r = 0 ; r < rows/splits ; r++) {
                for (int c = 0; c < columns; c++) {

                    // Logic for assigning a state, a value using probability distribution
                    max = 0;
                    for(int i=0;i<tiles.length;i++) {

                        if (count[r][c][i] > max) {
                            max = count[r][c][i];
                            maxID = i;

                        }

                    }
                    if (max > 0.4) {
                        scene[r][c] = tiles[maxID];
                        model.setBlock(c, model_row, scene[r][c]);
                    }

                    //Logic for assigning a state a value using markov chain
                    double m=0;
                    int mID=0;
                    if(r>1 && c>1) {

                        pe = MarkovChain(model_row, c, data, tiles);
                        for(int i = 0; i < pe.length; i++) {
                            if (m < pe[i]) {
                                m = pe[i];
                                mID = i;
                            }
                        }
                        scene[r][c] = tiles[mID];
                    }

                    if(m > thresh) {

                        model.setBlock(c, model_row, scene[r][c]);
                    }

                }
                model_row++;
            }
    }


    /***
     *
     * This is the function responsible for generating a level and returning it back to the framework as a string
     *
     * @param model contain a model of the level
     * @param timer contains the timing information (in case you want to build a map online)
     *
     * @return the generated level as a string
     *
     */
    @Override
    public String getGeneratedLevel(MarioLevelModel model, MarioTimer timer) {

        // variable traindata will contain the whole train data set ...

        char[][][] traindata = generateTrainData(type, NTD);

        // declaring different domains to be called
        char[] scene1 = model.getNonBlockingTiles();
        char[] scene2 = model.getBlockTiles();
        char[] enemy = model.getEnemyCharacters(false);

        // adjusting the enemy domain according to the difficulty
        if(difficulty > 2){
            enemy = model.getEnemyCharacters();
        }

        //taking into account the row splits
        for (int s = 1; s <= splits; s++) {

            // The level building
            BuildEnemy(model, traindata, s, enemy);
            BuildScene(model, traindata, s, scene1, "NonBlock");
            BuildScene(model, traindata, s, scene2, "Block");
            if(difficulty <= 2){
                BuildScene(model, traindata, s, model.getCollectablesTiles(), "Collect");
            }


        }

        // Filtering the levels
        FilterBotUp(model);
        FilterTopDown(model);

        // analysis metrics
        System.out.println("Corrections : " + corrections);
        System.out.println("Random count : " + random_counts);

        return model.getMap();
    }

    /***
     *
     * This function has the same functionality as the one of build scene. The reason it is written separately
     * is to take into account the difficulty part
     *
     * @param model an object of class MarioLevelModel used here for getting and setting tiles at specific x,y coordinates in a level
     * @param data  contains the train data
     * @param s represents the section or split that we are supposed to be working on
     * @param domain the domain or the tiles being considered for building (Blocking or Non Blocking)
     *
     */
    private void BuildEnemy(MarioLevelModel model, char[][][] data, int s, char[] domain) {
        char[] tiles = domain;
        double[][][] count = Probability_Distribution(data, s, tiles);
        double thresh = 0.1;

        if(difficulty > 2){
            thresh = 0.3;

        }
        int model_row = (rows * (s-1))/splits;

        char[][] scene = new char[rows/splits][columns];
        double[] pe = new double[domain.length];

        for (int r = 0 ; r < rows/splits ; r++) {
            for (int c = 10; c < columns; c++) {

                double m=0;
                int mID=0;
                if(r>1 && c>1) {
                    pe = MarkovChain(model_row, c, data, tiles);
                    for(int i = 0; i < pe.length; i++) {
                        if (m < pe[i]) {
                            m = pe[i];
                            mID = i;
                        }
                    }
                    scene[r][c] = tiles[mID];
                }
                if(m > thresh) {
                    model.setBlock(c, model_row, scene[r][c]);
                }

                if(random.nextFloat() > (0.98 - (difficulty/100)) ){
                    model.setBlock(c, model_row, model.getEnemyCharacters()[random.nextInt(model.getEnemyCharacters().length)]);
                    random_counts++;
                }

            }
            model_row++;
        }
    }

    /***
     * This is a filter function consists of some defined rules or constraints. It traverses the generated level in a
     * bottom up fashion and checks for elements that disobey the constrains. It also contains the logic for modifying
     * the generated level if any violation of constraints is detected.
     *
     * @param model :- it is the object of MarioLevelModel class which is used for getting or setting of elements at
     *              specific locations.
     */
    private void FilterBotUp(MarioLevelModel model) {

        // Loop to traverse bottom-up, left-right
        for(int r = rows-1; r>=0; r--) {
            for(int c = 0; c<columns; c++) {

                // Logic for listed collection of constraints and what to do when violation detected

                if (model.getBlock(c, r) == model.PIPE_FLOWER) {
                    if (model.getBlock(c, r - 1) != model.PIPE_FLOWER) {
                        model.setBlock(c, r - 1, model.EMPTY);
                        model.setBlock(c, r - 2, model.EMPTY);
                        corrections++;
                    }
                }
                if (model.getBlock(c, r) == model.PIPE) {
                    if (model.getBlock(c, r - 1) != model.PIPE) {
                        model.setBlock(c, r - 1, model.EMPTY);
                        model.setBlock(c, r - 2, model.EMPTY);
                        corrections++;
                    }
                }
                if (model.getBlock(c, r) == model.PLATFORM_BACKGROUND) {
                    if(model.getBlock(c+1,r) != model.PLATFORM_BACKGROUND){
                        model.setBlock(c+1,r,model.EMPTY);
                        corrections++;
                    }
                    if(model.getBlock(c+1,r) != model.PLATFORM_BACKGROUND && model.getBlock(c-1,r) != model.PLATFORM_BACKGROUND){
                        model.setBlock(c,r,model.EMPTY);
                        corrections++;
                    }
                    else{
                        if (model.getBlock(c, r - 1) != model.PLATFORM_BACKGROUND) {
                            model.setBlock(c, r - 1, model.PLATFORM);
                            corrections++;
                        }
                        for(int y=r; y<rows; y++){
                            model.setBlock(c,y,model.PLATFORM_BACKGROUND);
                            corrections++;
                        }
                    }
                }
                if(model.getBlock(c,r) == model.PLATFORM){
                    if(model.getBlock(c,r+1) != model.PLATFORM_BACKGROUND){
                        model.setBlock(c,r+1, model.getBlockTiles()[random.nextInt(model.getBlockTiles().length)]);
                        corrections++;
                    }
                    if(model.getBlock(c,r-1) != model.EMPTY){
                        model.setBlock(c,r-1, model.EMPTY);
                        corrections++;
                    }
                    if(model.getBlock(c-1,r) != model.PLATFORM){
                        model.setBlock(c-1,r, model.EMPTY);
                        model.setBlock(c-1,r-1, model.EMPTY);
                        corrections++;
                    }
                    if(model.getBlock(c+1,r) != model.PLATFORM){
                        model.setBlock(c+1,r, model.EMPTY);
                        model.setBlock(c+1,r-1, model.EMPTY);
                        corrections++;
                    }
                }
                if(model.getBlock(c,r) == model.PIPE_FLOWER) {

                    if (model.getBlock(c + 1, r) == model.PIPE_FLOWER && model.getBlock(c + 2, r) == model.PIPE_FLOWER) {
                        model.setBlock(c, r, model.EMPTY);
                        corrections++;
                    }

                    if (model.getBlock(c + 1, r) != model.PIPE_FLOWER && model.getBlock(c - 1, r) != model.PIPE_FLOWER) {
                        model.setBlock(c, r, model.EMPTY);
                        corrections++;
                    }
                }
                if(model.getBlock(c,r) == model.PIPE) {

                    if (model.getBlock(c + 1, r) == model.PIPE && model.getBlock(c + 2, r) == model.PIPE) {
                        model.setBlock(c, r, model.EMPTY);
                        corrections++;
                    }

                    if (model.getBlock(c + 1, r) != model.PIPE && model.getBlock(c - 1, r) != model.PIPE) {
                        model.setBlock(c, r, model.EMPTY);
                        corrections++;
                    }
                }

                if(model.getBlock(c,r) == model.PIPE_FLOWER) {

                    if (model.getBlock(c, r - 1) != model.PIPE_FLOWER && model.getBlock(c, r + 1) != model.PIPE_FLOWER) {
                        model.setBlock(c, r, model.EMPTY);
                        corrections++;
                    }

                }

                if(model.getBlock(c,r) != model.PIPE_FLOWER) {
                    if (model.getBlock(c + 1, r) == model.PIPE_FLOWER && model.getBlock(c, r + 1) == model.PIPE_FLOWER && model.getBlock(c + 1, r + 1) == model.PIPE_FLOWER) {
                        model.setBlock(c, r, model.PIPE_FLOWER);
                        corrections++;
                    }
                }
                if(model.getBlock(c,r) == model.PIPE) {

                    if (model.getBlock(c + 1, r) == model.PIPE && model.getBlock(c, r + 1) == model.PIPE && model.getBlock(c + 1, r + 1) == model.PIPE) {
                        model.setBlock(c, r, model.PIPE);
                        corrections++;
                    }

                    if (model.getBlock(c, r - 1) != model.PIPE && model.getBlock(c, r - 2) == model.PIPE) {
                        model.setBlock(c, r - 1, model.PIPE);
                        corrections++;
                    }
                }
            }
        }
    }

    /***
     * This is a filter function consists of some defined rules or constraints. It traverses the generated level in a
     * top down fashion and checks for elements that disobey the constrains. It also contains the logic for modifying
     * the generated level if any violation of constraints is detected. The reason for including this along with the
     * bottom up is because, after the bottom up, there are still some anomalies left.
     *
     * @param model :- it is the object of MarioLevelModel class which is used for getting or setting of elements at
     *              specific locations.
     */
    private void FilterTopDown(MarioLevelModel model) {

        // Code to traverse the level in top-down, left-right fashion
        for(int r = 0; r < rows; r++) {
            for(int c = 0; c<columns; c++) {

                // Logic for constraint enforcement
                if(model.getBlock(c,r) == model.PIPE_FLOWER) {
                    if(model.getBlock(c+1, r) != model.PIPE_FLOWER && model.getBlock(c-1, r) != model.PIPE_FLOWER){
                        model.setBlock(c, r, model.EMPTY);
                        corrections++;
                    }

                    if(model.getBlock(c,r+1) == model.COIN){
                            model.setBlock(c,r+1, model.PIPE_FLOWER);
                            corrections++;
                    }
                }

                for(int e = 0; e< model.getEnemyCharacters().length; e++){
                    if(r < 5) {
                        if (model.getBlock(c, r) == model.getEnemyCharacters()[e]) {
                            model.setRectangle(c,r+1,2,7,model.EMPTY);
                            corrections++;
                        }
                    }
                }
            }
        }
    }

    @Override
    public String getGeneratorName() {
        return "GroupAA Level Generator";
    }
}
