The package GroupAA contains 1 Java class and a folder which contains some of the levels used as training data
We request you to keep the folder as it is. No changes to its path or files to be done.

LevelGenerator.java -
This java file contains the implemented level generator. The code is well commented to guide you through. 
This contains 3 constructors that can be called for creation of an instance of this class. 
If you open the class, you will find all the major global parameters that we have used in our class with comments on what that parameter represents.
These are : 

    private final int rows = 16;    // map height
    private final int columns = 150;    // map width
    private int NTD =  2; // number of files to be read for training
    private int type = 1; //map type (notch, linear or benWeber)
    private Random random = new Random(); // for the touch of randomness in generation
    private int d_type = 5; // type of dependency
    private int splits = 2; // specify the number of horizontal splits
    private int difficulty = 2; // sets the difficulty for the Mario level
    private int corrections = 0; // keeps count of the number of times filter corrected the level
    private int random_counts = 0; // keeps count of the number of times an element had to be generated randomly

The values of rows and columns is fixed as asked in the assignment. Also, the last two variables are for analysis of the code and do not influence the level generation in any way.
For the rest of the them, you can call a default constructor with no parameters and change the values of these variables directly from the class. 
Or you can call a parameterized constructor and specify the values for these variables there.

Changing these parameters should provide you with different generated levels. You won't need to modify anything else in the code.


Instructions on using the constructor for creating the player -

MarioLevelGenerator generator = new levelGenerators.GroupAA.LevelGenerator( );
MarioLevelGenerator generator = new levelGenerators.GroupAA.LevelGenerator(type, NTD);
MarioLevelGenerator generator = new levelGenerators.GroupAA.LevelGenerator(type, NTD, splits, d_type, difficulty);

The values to be given in the contructors should be the same as that in the class parameter definition
type can take values {1,2,3} 
NTD can take values {1 to 100} [ Note: for type = 1, NTD can take values no more than 15]
splits can take values {1 to 5} [ can take more, but generates a blank map ]
d_type can take values {1 to 6} 
difficulty can take values {1 to 5}
